package com.cg.bean;

public class ComplaintCategory {

	private String complaintCategoryId;
	private String categoryName;
	public ComplaintCategory() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ComplaintCategory(String complaintCategoryId, String categoryName) {
		super();
		this.complaintCategoryId = complaintCategoryId;
		this.categoryName = categoryName;
	}
	public String getComplaintCategoryId() {
		return complaintCategoryId;
	}
	public void setComplaintCategoryId(String complaintCategoryId) {
		this.complaintCategoryId = complaintCategoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	@Override
	public String toString() {
		return "ComplaintCategory [complaintCategoryId=" + complaintCategoryId + ", categoryName=" + categoryName + "]";
	}
	
}
