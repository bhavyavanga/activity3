package com.cg.bean;

public class ComplaintBean {

	private String complaintNo;
	private ComplaintCategory complaintCategory;
	private String complaintDescription;
	private String complaintPriority;
	private String complaintStatus;
	private String comments;
	public ComplaintBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ComplaintBean(String complaintNo, ComplaintCategory complaintCategory, String complaintDescription,
			String complaintPriority, String complaintStatus, String comments) {
		super();
		this.complaintNo = complaintNo;
		this.complaintCategory = complaintCategory;
		this.complaintDescription = complaintDescription;
		this.complaintPriority = complaintPriority;
		this.complaintStatus = complaintStatus;
		this.comments = comments;
	}
	public String getComplaintNo() {
		return complaintNo;
	}
	public void setComplaintNo(String complaintNo) {
		this.complaintNo = complaintNo;
	}
	public ComplaintCategory getComplaintCategory() {
		return complaintCategory;
	}
	public void setComplaintCategory(ComplaintCategory complaintCategory) {
		this.complaintCategory = complaintCategory;
	}
	public String getComplaintDescription() {
		return complaintDescription;
	}
	public void setComplaintDescription(String complaintDescription) {
		this.complaintDescription = complaintDescription;
	}
	public String getComplaintPriority() {
		return complaintPriority;
	}
	public void setComplaintPriority(String complaintPriority) {
		this.complaintPriority = complaintPriority;
	}
	public String getComplaintStatus() {
		return complaintStatus;
	}
	public void setComplaintStatus(String complaintStatus) {
		this.complaintStatus = complaintStatus;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	@Override
	public String toString() {
		return "complaintNo=" + complaintNo + ", complaintCategory=" + complaintCategory
				+ ", complaintDescription=" + complaintDescription + ", complaintPriority=" + complaintPriority
				+ ", complaintStatus=" + complaintStatus + ", comments=" + comments;
	}
	
}
