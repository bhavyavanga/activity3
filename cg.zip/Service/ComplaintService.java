package com.cg.Service;

import java.util.List;

import com.cg.bean.ComplaintBean;
import com.cg.bean.ComplaintCategory;

public interface ComplaintService {

	 boolean raiseNewComplaint(ComplaintBean complaintBean);
	    List<ComplaintCategory> listComplaintCategory();
	    int ComplaintId();
	
}
