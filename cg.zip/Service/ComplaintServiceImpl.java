package com.cg.Service;

import java.util.ArrayList;
import java.util.List;

import com.cg.Dao.ComplaintDao;
import com.cg.Dao.ComplaintDaoImpl;
import com.cg.bean.ComplaintBean;
import com.cg.bean.ComplaintCategory;

public class ComplaintServiceImpl implements ComplaintService {

	ComplaintDao complaintDao=new ComplaintDaoImpl();
	List<ComplaintBean> list11=new ArrayList<>();

	 

	    public boolean raiseNewComplaint(ComplaintBean complaintBean) {
	        
	        return complaintDao.raiseNewComplaint(complaintBean);
	    }

	 

	    public List<ComplaintCategory> listComplaintCategory() {
	        //List<ComplaintCategory> complaintCategory =new ArrayList<ComplaintCategory>();
	        //Collection<ComplaintCategory> collection=complaintDao.listComplaintCategory();
	        //complaintCategory.addAll(collection);
	        return complaintDao.listComplaintCategory();
	    }

	 

	    @Override
	    public int ComplaintId() {
	        int complaintId=(int)(Math.random()*1000);
	        return complaintId;
}
}