package com.cg.ui;

import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;


import com.cg.Service.ComplaintServiceImpl;
import com.cg.bean.ComplaintCategory;


public class MainUI {

	static ComplaintServiceImpl service = new ComplaintServiceImpl();
	static Scanner scanner = new Scanner(System.in);

	static void SoftwareProblem() {
		System.out.println("Enter ComplaintNo");
		String complaintNo = scanner.next();
		System.out.println("Enter description");
		String description = scanner.next();
		System.out.println("Enter Priority");
		String priority = scanner.next();
		Date d1=new Date();
		Calendar c=Calendar.getInstance();
		
		ComplaintCategory complaint = new ComplaintCategory(description,priority);
       // int complaintId = service.raiseNewCompliant(complaint);
        System.out.println("Your compliant number" +complaintNo+"register successfully at"+ d1+"Time:"+c.get(Calendar.HOUR)+":"+c.get(Calendar.MINUTE)+":"+c.get(Calendar.AM_PM) );

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String option = null;
		do {
			System.out.println("1.SoftwareProblem\n 2.hardwareProblem\n 3.internetProblem\n 4.other issues");
			int choice = scanner.nextInt();
			switch (choice) {
			case 0:
				System.exit(0);
			case 1:
				SoftwareProblem();

			}
			System.out.println("press y to continue");
			option = scanner.next();
		} while (option.equalsIgnoreCase("y"));

	}

}
