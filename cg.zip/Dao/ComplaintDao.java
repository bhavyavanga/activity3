package com.cg.Dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.bean.ComplaintBean;
import com.cg.bean.ComplaintCategory;
import com.cg.exception.ComplaintException;

public interface ComplaintDao {

	boolean raiseNewComplaint(ComplaintBean complaintBean);
	List<ComplaintCategory> listComplaintCategory();
	
}
