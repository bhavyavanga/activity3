package com.cg.Dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import com.cg.bean.ComplaintBean;
import com.cg.bean.ComplaintCategory;

public class ComplaintDaoImpl implements ComplaintDao {
	List<ComplaintBean> list21=new ArrayList<>();
	private static Map<String, String> complaintCategory=new HashMap<String, String>();
	public static Map<String, String> getComplaintCategoryEntries(){
	    complaintCategory.put("C001", "software problem");
	    complaintCategory.put("C002", "hardware problem");
	    complaintCategory.put("C004", "internet problem");
	    complaintCategory.put("C003", " other issues");
	    return complaintCategory;
	    
	}
	    public boolean raiseNewComplaint(ComplaintBean complaintBean) {
	        if(complaintBean==null)
	            return false;
	        return list21.add(complaintBean);
	        
	    }
	    //ArrayList<Integer> keyList = new ArrayList<Integer>(myMap.keySet());
	   // ArrayList<String> valueList = new ArrayList<String>(myMap.values());

	 


	    public List<ComplaintCategory> listComplaintCategory() {
	        List<ComplaintCategory> complaintCategories=new ArrayList<>();
	        List<String> valueList=new ArrayList<>(getComplaintCategoryEntries().values());
	        Iterator<String> iterator=valueList.iterator();
	        int i=1;
	        while(iterator.hasNext()) {
	            String catName=iterator.next();
	        ComplaintCategory cc=new ComplaintCategory(String.valueOf(i),catName);
	        complaintCategories.add(cc);
	        i++;
	        }
	        
	        return complaintCategories;
	        
	        
	}

}
